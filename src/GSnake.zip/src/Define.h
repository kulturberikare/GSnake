/*
 * Define.h
 *
 *  Created on: 26 nov 2012
 *      Author: nimbe760
 */

#ifndef DEFINE_H_
#define DEFINE_H_

#define WWIDTH 	800
#define WHEIGHT 600

#define OBJSIDE 20

#endif
